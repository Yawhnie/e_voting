<?php $this->pageTitle=Yii::app()->name . ' - '.Yum::t('Messages'); ?>

<h1><?php echo $title; ?></h1>

<div class="form">
<?php echo $content; ?>

</div><!-- yiiForm -->
