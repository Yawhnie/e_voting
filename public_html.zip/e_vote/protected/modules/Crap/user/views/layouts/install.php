<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/screen.css" media="screen, projection" />

<div style="margin: 10px;">
<?php echo $content; ?>
</div>
