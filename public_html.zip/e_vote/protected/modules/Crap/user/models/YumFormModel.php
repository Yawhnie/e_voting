<?php
/**
 * Base form model class
 * @author tomasz.suchanek
 * @since 0.6
 * @package Yum.core
 *
 */
abstract class YumFormModel extends CFormModel
{
	
}
?>