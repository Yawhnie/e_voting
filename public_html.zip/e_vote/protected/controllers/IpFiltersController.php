<?php

class IpFiltersController extends Controller

{
public function ips()
	{
		return array(
			array('deny',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('create','view','admin','delete','update'),
				'ips'=>array('127.0.0.1','::1'),
			),
		);
	}

}