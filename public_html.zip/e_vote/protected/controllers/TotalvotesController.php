<?php

class TotalvotesController extends Controller
{
	public function actionResults()
	{
		$this->render('results');
	}
	public function analysis()
	{
		
		$sql2 = "select count(DISTINCT userid) as voters from {{authassignment}} auth JOIN {{Voters}} vt where auth.userid = vt.VoterId AND itemname = 'Authenticated'";
		$totvoters = Yii::app()->db->createCommand($sql2)->query()->read();
		echo "Total Registred Voters :".$totvoters['voters']."<br />";
		
		$sql = "SELECT COUNT(DISTINCT VoterId) as total FROM {{Status}}";
		
		$totvote = Yii::app()->db->createCommand($sql)->query()->read();
		
		echo "Total Voters TurnOut :".$totvote['total']."<br />";
		$turnout = ($totvote['total']/$totvoters['voters'])*100;
		
		echo "Percentage TurnOut : ".round($turnout,2)."%<br />";
		
		/*$array=array(array($totvote['total'],'TurnOut'),array($totvoters['voters'],'Voters'),array($turnout,'Percentage'));

		$this->widget('jqBarGraph',
		array('values'=>$array,
		'type'=>'simple',
		'width'=>200,
		'color1'=>'#122A47',
		'color2'=>'#1B3E69',
		'color3'=>'#CCCCCC',
		'space'=>5,
		'title'=>'Trial Demo'));*/
		
	}

	// Uncomment the following methods and override them if needed
	/*
	public function filters()
	{
		// return the filter configuration for this controller, e.g.:
		return array(
			'inlineFilterName',
			array(
				'class'=>'path.to.FilterClass',
				'propertyName'=>'propertyValue',
			),
		);
	}

	public function actions()
	{
		// return external action classes, e.g.:
		return array(
			'action1'=>'path.to.ActionClass',
			'action2'=>array(
				'class'=>'path.to.AnotherActionClass',
				'propertyName'=>'propertyValue',
			),
		);
	}
	*/
}