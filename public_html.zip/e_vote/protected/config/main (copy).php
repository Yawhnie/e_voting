<?php

// uncomment the following to define a path alias
// Yii::setPathOfAlias('local','path/to/local-folder');

// This is the main Web application configuration. Any writable
// CWebApplication properties can be configured here.
return array(
	'basePath'=>dirname(__FILE__).DIRECTORY_SEPARATOR.'..',
	'name'=>'E-voting',

	// preloading 'log' component
	'preload'=>array('log'),

	// autoloading model and component classes
	'import'=>array(
		'application.models.*',
		'application.components.*',
		'application.modules.user.*',
		'application.modules.rights.*',//add for right based authenticate
		'application.modules.rights.components.*',//add for right based authenticate
		'application.extensions.debugtoolbar.*',//add for right based authenticate
	),

	'modules'=>array(
		// uncomment the following to enable the Gii tool
		
		'gii'=>array(
			'class'=>'system.gii.GiiModule',
			'password'=>'YAWHNIE',
		 	// If removed, Gii defaults to localhost only. Edit carefully to taste.
			'ipFilters'=>array('127.0.0.1','::1'),
		),
		'user' => array(
			'install'=>false,
			'debug' => true,
			'usersTable' => 'evt_Voters',
			'translationTable' => 'evt_translation',
			),
			/*'usergroup' => array(
			'usergroupTable' => 'evt_user_group',
			'usergroupMessagesTable' => 'evt_user_group_message',
			),
			'membership' => array(
			'membershipTable' => 'evt_membership',
			'paymentTable' => 'evt_payment',
			),
			'friendship' => array(
			'friendshipTable' => 'evt_friendship',
			),
			'profile' => array(
			'privacySettingTable' => 'evt_privacy_setting',
			'profileFieldsGroupTable' => 'evt_profile_field_group',
			'profileFieldsTable' => 'evt_profile_field',
			'profileTable' => 'profile',
			'profileCommentTable' => 'profile_comment',
			'profileVisitTable' => 'evt_profile_visit',
			),
			'role' => array(
			'rolesTable' => 'evt_role',
			'userHasRoleTable' => 'evt_user_role',
			'actionTable' => 'evt_action',
			'permissionTable' => 'evt_permission',
			),
			'messages' => array(
			'messagesTable' => 'evt_message',
			),*/
		'rights'=>array(
			'debug'=>true,
			'install'=>false,
			'enableBizRuleData'=>true,
		),//add for right based authenticate from rights
		
	),

	// application components
	'components'=>array(
		'user'=>array(
			'class'=>'RWebUser', //add for right based authenticate
			// enable cookie-based authentication
			//'allowAutoLogin'=>true,
		//'class' => 'application.modules.user.components.YumWebUser',
		'allowAutoLogin'=>true,
		'loginUrl' => array('/site/login'),
		),
		// uncomment the following to enable URLs in path-format
		/*
		'urlManager'=>array(
			'urlFormat'=>'path',
			'rules'=>array(
				'<controller:\w+>/<id:\d+>'=>'<controller>/view',
				'<controller:\w+>/<action:\w+>/<id:\d+>'=>'<controller>/<action>',
				'<controller:\w+>/<action:\w+>'=>'<controller>/<action>',
			),
		),
		*/
		/*'db'=>array(
			'connectionString' => 'sqlite:'.dirname(__FILE__).'/../data/testdrive.db',
		),*/
		// uncomment the following to use a MySQL database
		
		'db'=>array(
			'connectionString' => 'mysql:host=localhost;dbname=evoting',
			'emulatePrepare' => true,
			'username' => 'root',
			'password' => '1PUMQ2',
			'charset' => 'utf8',
			'tablePrefix' => 'evt_',
		),
		
		'authManager'=>array(
		'class'=>'RDbAuthManager',
		'connectionID'=>'db',
		'itemTable'=>'evtg_authitem',
		'itemChildTable'=>'evt_authitemchild',
		'assignmentTable'=>'evt_authassignment',
		'rightsTable'=>'evt_rights',
			),
			'errorHandler'=>array(
			// use 'site/error' action to display errors
            'errorAction'=>'site/error',
        ),
		'log'=>array(
			'class'=>'CLogRouter',
			'routes'=>array(
				array(
					'class'=>'CFileLogRoute',
					'levels'=>'error, warning',
				),
				
			),
		),
			),

			

	// application-level parameters that can be accessed
	// using Yii::app()->params['paramName']
	'params'=>array(
		// this is used in contact page
		'adminEmail'=>'yawhnie@gmail.com',
	),
);