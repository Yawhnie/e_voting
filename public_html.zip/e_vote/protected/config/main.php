<?php

// uncomment the following to define a path alias
// Yii::setPathOfAlias('local','path/to/local-folder');

// This is the main Web application configuration. Any writable
// CWebApplication properties can be configured here.
return array(
	'basePath'=>dirname(__FILE__).DIRECTORY_SEPARATOR.'..',
	'name'=>'Online Voting',
	'theme'=>'yawhnie_theme',
	//'theme'=>'',
	// preloading 'log' component
	'preload'=>array('log'),

	// autoloading model and component classes
	'import'=>array(
		'application.models.*',
		'application.components.*',
		'application.modules.rights.*',
		'application.extensions.jqBarGraph.*',
		'application.modules.rights.components.*',
		'application.extensions.debugtoolbar.*',
		'application.uploads.*',
	),

	'defaultController'=>'site',

	// application modules
	'modules'=>array(
	
		'gii'=>array(
			'class'=>'system.gii.GiiModule',
			'password'=>'YAWHNIE',
		 	// If removed, Gii defaults to localhost only. Edit carefully to taste.
			'ipFilters'=>array('127.0.0.1','::1'),
		),
		'rights'=>array(
			'debug'=>true,
			//'install'=>true,
			'enableBizRuleData'=>true,
		),
    ),

	// application components
	'components'=>array(
	
		'user'=>array(
			'class'=>'RWebUser',
			// enable cookie-based authentication
			'allowAutoLogin'=>true,
		),
		'db'=>array(
			'connectionString' => 'mysql:host=localhost;dbname=evoting',
			'emulatePrepare' => true,
			'username' => 'root',
			'password' => '1PUMQ2',
			'charset' => 'utf8',
			'tablePrefix' => 'evt_',
		),
		'authManager'=>array(
			'class'=>'RDbAuthManager',
			'connectionID'=>'db',
			'itemTable'=>'evt_authitem',
			'itemChildTable'=>'evt_authitemchild',
			'assignmentTable'=>'evt_authassignment',
			'rightsTable'=>'evt_rights',
		),
		'session'=>array(
			'autoStart'=>true,
			//'sessionName'=>'Site Access',
			//'cookieMode'=>'only',
			'class'=>'system.web.CDbHttpSession',
			'connectionID'=>'db',
			'sessionTableName'=>'evt_Sessions',
			'timeout'=>1800,
		),
		'errorHandler'=>array(
			// use 'site/error' action to display errors
            'errorAction'=>'site/error',
        ),
		'request'=>array(
			'enableCsrfValidation'=>true,
		),
        /*'urlManager'=>array(
        	'urlFormat'=>'path',
        	'rules'=>array(
        		'post/<id:\d+>/<title:.*?>'=>'post/view',
        		'posts/<tag:.*?>'=>'post/index',
        		'<controller:\w+>/<action:\w+>'=>'<controller>/<action>',
        	),
        ),*/
		'log'=>array(
			'class'=>'CLogRouter',
			'routes'=>array(
				array(
					'class'=>'CFileLogRoute',
					'levels'=>'error, warning',
				),
				// debug toolbar configuration
				/*array(
					'class'=>'XWebDebugRouter',
					'config'=>'alignLeft, opaque, runInDebug, fixedPos, collapsed, yamlStyle',
					'levels'=>'error, warning, trace, profile, info',
					'allowedIPs'=>array('127.0.0.1'),
				),*/
				// uncomment the following to show log messages on web pages
				/*
				array(
					'class'=>'CWebLogRoute',
				),
				*/
			),
		),
	),

	// application-level parameters that can be accessed
	// using Yii::app()->params['paramName']
	'params'=>require(dirname(__FILE__).'/params.php'),
);
