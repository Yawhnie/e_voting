<?php

/**
 * This is the model class for table "evt_Candidates".
 *
 * The followings are the available columns in table 'evt_Candidates':
 * @property integer $CandidateId
 * @property integer $PositionId
 * @property string $FName
 * @property string $ONames
 * @property integer $Votes
 */
class Candidates extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return Candidates the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return '{{Candidates}}';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('PositionId,FName, ONames', 'required'),
			array('Votes', 'numerical', 'integerOnly'=>true),
			array('FName', 'length', 'max'=>25),
			array('ONames', 'length', 'max'=>30),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			//array('CandidateId, PositionId, FName, ONames, Votes', 'safe', 'on'=>'search'),
			array('binaryImg','file','types'=>'jpg,jpeg,png,gif',
				//'wrongType'=>'',
				'maxSize'=>1024*1024,'tooLarge'=>'The Image Is Too large, we recommend not larger than 1 MB',
				'allowEmpty' => true,
				),
			array('imgName','unique','allowEmpty'=>true),
		);
	}
	
	public function attributeLabels()
	{
		return array(
			'CandidateId' => 'Candidate Id',
			'PositionId' => 'Position Id',
			'FName' => 'First name',
			'ONames' => 'Other Names',
			'Votes' => 'Votes',
			'binaryImg'=>'Upload Image',
			'imgName'=>'Image Name',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('CandidateId',$this->CandidateId);
		$criteria->compare('PositionId',$this->PositionId);
		$criteria->compare('FName',$this->FName,true);
		$criteria->compare('ONames',$this->ONames,true);
		$criteria->compare('Votes',$this->Votes);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}
