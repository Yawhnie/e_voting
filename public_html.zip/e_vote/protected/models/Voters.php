<?php

/**
 * This is the model class for table "evt_Voters".
 *
 * The followings are the available columns in table 'evt_Voters':
 * @property integer $VoterId
 * @property string $FName
 * @property string $ONnames
 * @property integer $NationalId
 * @property string $RegNo
 * @property string $Email
 * @property string $Password
 */
class Voters extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return Voters the static model class
	 */
	public $captchaCode;
	
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return '{{Voters}}';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	 
	public $Password_confirm;
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.nal Contains Numbers Only
		return array(
			array('FName, ONnames,NationalId, RegNo ,Password, Password_confirm', 'required'),
			array('NationalId', 'numerical', 'integerOnly'=>true,'message'=>'National Contains Numbers Only'),
			array('FName', 'length', 'max'=>25),
			array('ONnames', 'length', 'max'=>30),
			array('RegNo', 'length', 'max'=>20),
			array('Email','email','message'=>'The Entered email address is invalid'),
			array('RegNo,NationalId','unique'),
			array('Password_confirm','compare','compareAttribute'=>'Password','message'=>'Passwords Do not match'),
			//array('captchaCode', 'captcha','allowEmpty'=>!CCaptcha::checkRequirements()),
			//array('Password', 'length', 'max'=>100),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('FName, ONnames, NationalId, RegNo, Email', 'safe', 'on'=>'search'),
		);
	}
	public function beforeSave()
	{
		if($this->getIsNewRecord())
		{
			$validStd = MainRegister::confirmCandidate($this->RegNo,$this->NationalId,$this->FName,$this->ONnames);
		
			if($validStd == true)
			{
				if(parent::beforeSave())
				{
					$this->Password=MD5($this->Password);
					return true;
				}
			}
			else 
			{
				$this->addError('Entries','Invalid Entries For Registration, no matching records for '.$this->RegNo);
				return false;
			}
		}
		else
		{
			return true;
		}
	}
	public function afterSave()
	{
		
		if($this->getIsNewRecord())
		{	
			//$sql = "INSERT INTO {{Status}} VALUES($this->VoterId,'')";
			$sql2 = "INSERT INTO {{authassignment}} VALUES('Authenticated',$this->VoterId,'','')";
			Yii::app()->db->createCommand($sql2)->execute();
			//$connection = Yii::app()->db->createCommand($sql)->execute();
			return true;
		}
		else
		{
			return true;
		}
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'VoterId' => 'Voter',
			'FName' => 'Fast Name',
			'ONnames' => 'Other Names',
			'NationalId' => 'National Id No.',
			'RegNo' => 'Registration  No.',
			'Email' => 'Email Address',
			'Password' => 'Select Password',
			'Password_confirm' => 'Confirm Password',
			'captchaCode'=>'Verification Code',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		//$criteria->compare('VoterId',$this->VoterId);
		$criteria->compare('FName',$this->FName,true);
		$criteria->compare('ONnames',$this->ONnames,true);
		$criteria->compare('NationalId',$this->NationalId,true);
		$criteria->compare('RegNo',$this->RegNo,true);
		//$criteria->compare('Email',$this->Email,true);
		//$criteria->compare('Password',$this->Password,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}