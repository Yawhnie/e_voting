<?php

class IpFilters extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return Expenses the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
	public function accessRules()
	{
		//IpFiltersController::ips();
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('create','view','admin','delete','update'),
				'ips'=>array('127.0.0.1','::1'),
			),
		);
	}
	
}