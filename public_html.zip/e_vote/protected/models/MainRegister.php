<?php

/**
 * This is the model class for table "{{MainRegister}}".
 *
 * The followings are the available columns in table '{{MainRegister}}':
 * @property string $RegistrationNo
 * @property integer $NationalId
 * @property string $SurName
 * @property string $OtherNames
 */
class MainRegister extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return MainRegister the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return '{{MainRegister}}';
	}
	public function confirmCandidate($regNo,$NationalId,$SName,$OName)
	{
		/*$sql = "SELECT * FROM {{MainRegister}} WHERE RegistrationNo = '$regNo' AND NationalId = '$NationalId' AND SurName LIKE '%$SName%' AND OtherNames LIKE '%$OName%'";
		
		$checkValidity = Yii::app()->db->createCommand($sql)->query();
		
		return $checkValidity;*/
		$SName = "%".$SName."%";
		$OName = "%".$OName."%";
		$checkValidity = Yii::app()->db->createCommand()
			->select(array('*'))
			->from('{{MainRegister}}')
			->where(array('and','RegistrationNo = "'.$regNo.'"','NationalId = '.$NationalId,'SurName LIKE "'.$SName.'"','OtherNames LIKE "'.$OName.'"'))
			->queryRow();
		return $checkValidity;
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('RegistrationNo, NationalId, SurName, OtherNames', 'required'),
			array('NationalId', 'numerical', 'integerOnly'=>true),
			array('RegistrationNo, SurName, OtherNames', 'length', 'max'=>30),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('RegistrationNo, NationalId, SurName, OtherNames', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'RegistrationNo' => 'Registration No',
			'NationalId' => 'National',
			'SurName' => 'Sur Name',
			'OtherNames' => 'Other Names',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('RegistrationNo',$this->RegistrationNo,true);
		$criteria->compare('NationalId',$this->NationalId);
		$criteria->compare('SurName',$this->SurName,true);
		$criteria->compare('OtherNames',$this->OtherNames,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}