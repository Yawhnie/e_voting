<?php

/**
 * LoginForm class.
 * LoginForm is the data structure for keeping
 * user login form data. It is used by the 'login' action of 'SiteController'.
 */
class LoginForm extends CFormModel
{
	//public $username;
	public $password;
	//public $rememberMe;
	public $registration_no;
	public $nationadid_no;
	//private $_identity;

	/**
	 * Declares the validation rules.
	 * The rules state that username and password are required,
	 * and password needs to be authenticated.
	 */
	public function rules()
	{
		return array(
			// username and password are required
			array('registration_no,nationadid_no, password', 'required'),
			// rememberMe needs to be a boolean
			//array('rememberMe', 'boolean'),
			// password needs to be authenticated
			array('registration_no,nationadid_no,password', 'authenticate'),
		);
	}

	/**
	 * Declares attribute labels.
	 */
	public function attributeLabels()
	{

	}

	/**
	 * Authenticates the password.
	 * This is the 'authenticate' validator as declared in rules().
	 */
	public function authenticate($attribute,$params)
	{
		if(!$this->hasErrors())
		{
			$identity=new UserIdentity($this->registration_no,$this->nationadid_no,$this->password);
			if(!$identity->authenticate())
				//$this->addError('password','Incorrect username or password.');
				switch($identity->errorCode)
				{
					case UserIdentity::ERROR_NONE:
						Yii::app()->user->login($identity);
						break;
					case UserIdentity::ERROR_REGISTARTION_INVALID:
						$this->addError('registration_no','Invalid registration No.');
						break;
					case UserIdentity::ERROR_NATIONALID_INVALID:
						$this->addError('nationalid_no','Invalid National Id No');
						break;
					case UserIdentity::ERROR_PASSWORD_INVALID:
						$this->addError('password','Password is incorrect.');
						break;
				}
		}
	}

	/**
	 * Logs in the user using the given username and password in the model.
	 * @return boolean whether login is successful
	 */
	public function login()
	{
		$identity=new UserIdentity($this->registration_no,$this->nationadid_no,$this->password);
		if($identity===null)
		{
			$identity->authenticate();
		}
	}
}
