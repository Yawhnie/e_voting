<?php

/**
 * This is the model class for table "{{VoteCount}}".
 *
 * The followings are the available columns in table '{{VoteCount}}':
 * @property integer $VoteId
 * @property integer $CandidateId
 * @property integer $PositionId
 * @property string $Time
 */
class Vote extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return Vote the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
	
	public function updateTotal()
	{
		$pos = Positions::model()->findAll(array('order'=>'PositionId'));
	
		foreach($pos as $post)
		{
			//echo "<h1>".$post['PositionName']."</h1>";
			$cand = Candidates::model()->findAll('PositionId=:PositionId',array('PositionId'=>$post['PositionId']));
			
			foreach($cand as $candidate)
			{
				$sql = "select count(CandidateId) as total from {{VoteCount}} where CandidateId = ". $candidate['CandidateId']." AND PositionId = ".$post['PositionId'];
				$result = Yii::app()->db->createCommand($sql)->query()->read();
				$sql2 = "update {{Candidates}} set Votes = ".$result['total']."  WHERE CandidateId = ". $candidate['CandidateId']." AND Votes < ".$result['total'];
				$result2 = Yii::app()->db->createCommand($sql2)->execute();
				//echo var_dump($result);
				//$candidateName = $candidate['FName']." ".$candidate['ONames'];
				//echo $candidateName." ".$result['total']."<br /><br />";
			}
		}
	}
	public function checkVoteStatus($userId)
	{
		//$userId = Yii::app()->user->id;
		$checkStatus = Yii::app()->db->createCommand()
			->select(array('VoterId','Status','itemname'))
			->from('{{Status}} s')
			->join('{{authassignment}} a','s.VoterId=a.userid')
			->where('VoterId = '.$userId)
			->where(array('and','s.VoterId = '.$userId,'a.itemname = "Authenticated"'))
			->queryRow();
		return $checkStatus;
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return '{{VoteCount}}';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('CandidateId, PositionId', 'numerical', 'integerOnly'=>true),
			array('Time', 'safe'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('VoteId, CandidateId, PositionId, Time', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	 public function beforeSave()
	{
		$checkStatus = VoteController::checkStatus($this->PositionId);
		
		if($checkStatus == false)
		{
			$this->Time=date('H:i:s');
			if($this->CandidateId == null)
			{
				return false;
			}
			else
			{
				return true;
			}
			return true;
		}
		else
		{
			return false;
		}
	}
	public function afterSave()
	{
		$UserId = Yii::app()->user->id;
		$sql = "INSERT INTO {{Status}} VALUES($UserId,'$this->PositionId')";
		$connection = Yii::app()->db->createCommand($sql)->execute();
		$this->updateTotal();
		return true;
	}
	public function attributeLabels()
	{
		return array(
			'VoteId' => 'Vote',
			'CandidateId' => 'Candidate',
			'PositionId' => 'Position',
			'Time' => 'Time',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('VoteId',$this->VoteId);
		$criteria->compare('CandidateId',$this->CandidateId);
		$criteria->compare('PositionId',$this->PositionId);
		$criteria->compare('Time',$this->Time,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}