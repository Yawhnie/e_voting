<?php

/**
 * This is the model class for table "{{Expenses}}".
 *
 * The followings are the available columns in table '{{Expenses}}':
 * @property integer $id
 * @property string $binaryfile
 * @property string $fileName
 * @property string $fileType
 */
class Expenses extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return Expenses the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return '{{Expenses}}';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			//array('binaryfile, fileName, fileType', 'required'),
			array('fileName', 'length', 'max'=>100),
			array('fileType', 'length', 'max'=>50),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, binaryfile, fileName, fileType', 'safe', 'on'=>'search'),
			array('binaryfile', 'file','types'=>'jpg, gif, png, bmp, jpeg','maxSize'=>1024 * 1024 * 10, // 10MB
			'tooLarge'=>'The file was larger than 10MB. Please upload a smaller file.','allowEmpty' => true
			),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'binaryfile' => 'Binaryfile',
			'fileName' => 'File Name',
			'fileType' => 'File Type',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('binaryfile',$this->binaryfile,true);
		$criteria->compare('fileName',$this->fileName,true);
		$criteria->compare('fileType',$this->fileType,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}