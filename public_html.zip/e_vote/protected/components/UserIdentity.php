<?php

/**
 * UserIdentity represents the data needed to identity a user.
 * It contains the authentication method that checks if the provided
 * data can identity the user.
 */
class UserIdentity extends CUserIdentity
{
	/**
	 * Authenticates a user.
	 * The example implementation makes sure if the username and password
	 * are both 'demo'.
	 * In practical applications, this should be changed to authenticate
	 * against some persistent user identity storage (e.g. database).
	 * @return boolean whether authentication succeeds.
	 */
	private $_id;
	public function authenticate()
	{
		$this->registration_no = stripslashes(strip_tags(htmlspecialchars($this->registration_no)));
		
		$sql = "SELECT * FROM {{Voters}} WHERE RegNo = '$this->registration_no'";

		$voters = Yii::app()->db->createCommand($sql)->query();
		
		$voter = $voters->read();
		
		if($voter == null)
		{
			$this->errorCode=self::ERROR_REGISTARTION_INVALID;//or use UserIdentity::ERROR_REGISTARTION_INVALID
		}
		else if($voter['NationalId'] !== stripslashes(strip_tags(htmlspecialchars($this->nationalid_no))))
		{
			$this->errorCode=self::ERROR_NATIONALID_INVALID;
		}
		else if($voter['Password'] !== MD5($this->password))
		{
			$this->errorCode=self::ERROR_PASSWORD_INVALID;
		}
		else
		{
			$this->errorCode=self::ERROR_NONE;
			$this->_id=$voter['VoterId'];
			$this->registration_no=$voter['RegNo'];
		}
	}
	public function getId()
	{
		return $this->_id;
	}
}
