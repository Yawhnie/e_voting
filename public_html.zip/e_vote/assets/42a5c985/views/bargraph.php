<div id="simpleGraph"></div>
<div id="multiGraph"></div>
<div id="stackedGraph"></div>

